<template>
  <div class="app-container">
    <el-row :gutter="20"
            style="height: 280px;overflow: hidden;margin-bottom:20px;">
      <el-col :span="10"
              height="200">
        <el-card class="box-card">
          <div slot="header"
               class="clearfix">
            <span style="color:#0782e4;font-weight: bold;">新闻列表</span>
          </div>
          <div style="margin-bottom:0px;">
            <el-table :data="minuteData"
                      :show-header="false"
                      style="width: 100%;">
              <el-table-column prop="title"
                               min-width="100">
              </el-table-column>
              <el-table-column prop="time"
                               min-width="150">
              </el-table-column>
              <el-table-column>
                <template slot-scope="{row}">
                  <router-link :to="'/tongzhi/minute/xiangxi?id='+row.id">
                    <el-button type="text"
                               style="color:#303133">&emsp;查看详细</el-button>
                  </router-link>
                </template>
                查看详细
              </el-table-column>
            </el-table>
          </div>
        </el-card>
      </el-col>
      <el-col :span="14">
        <el-card class="box-card">
          <div slot="header"
               class="clearfix">
            <span style="color:#0782e4;font-weight: bold;">公告列表</span>
          </div>
          <div style="margin-bottom:0px;">
            <el-table :data="noticData"
                      :show-header="false"
                      style="width: 100%">
              <el-table-column prop="noticName"
                               min-width="100">
              </el-table-column>
              <el-table-column min-width="150">
                <template slot-scope="{row}">
                  {{row.nTyle.typeName}}
                </template>
              </el-table-column>
              <el-table-column prop="time"
                               min-width="150">
              </el-table-column>

              <el-table-column min-width="100">
                <template slot-scope="{row}">
                  <router-link :to="'/tongzhi/notic/tongzhix?id='+row.id">
                    <el-button type="text"
                               style="color:#303133">&emsp;{{ row.isQueren==1?"需要确认":"查看详细"}}</el-button>
                  </router-link>
                </template>
              </el-table-column>
            </el-table>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <el-row :gutter="20"
            style="border-top:1px solid #dfe6ec;height: 400px;overflow: hidden;padding-top:20px">
      <el-col :span="8"
              height="200">
        <el-card class="box-card">
          <div slot="header"
               class="clearfix">
            <span style="color:#0782e4;font-weight: bold;">我的申请</span>
          </div>
          <div style="margin-bottom:0px;">
            <el-table :data="shenqingData"
                      :show-header="false"
                      style="width: 100%;">
              <el-table-column prop="exampleName"
                               min-width="80">
              </el-table-column>
              <el-table-column prop="processName"
                               min-width="100">
              </el-table-column>
              <el-table-column prop="stratTime"
                               min-width="100">
              </el-table-column>

              <el-table-column>
                <template slot-scope="{row}">
                  <router-link :to="'/flow/processExample/xiangxi?id='+row.id">
                    <el-button type="text"
                               style="color:#303133">&emsp;查看详细</el-button>
                  </router-link>
                </template>
                查看详细
              </el-table-column>
            </el-table>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8"
              height="200">
        <el-card class="box-card">
          <div slot="header"
               class="clearfix">
            <span style="color:#0782e4;font-weight: bold;">我的待办</span>
          </div>
          <div style="margin-bottom:0px;">
            <el-table :data="shenHeData"
                      :show-header="false"
                      style="width: 100%;">
              <el-table-column prop="username"
                               min-width="80">
              </el-table-column>
              <el-table-column prop="processName"
                               min-width="100">
              </el-table-column>
              <el-table-column prop="stratTime"
                               min-width="100">
              </el-table-column>
              <el-table-column>
                <template slot-scope="{row}">
                  <router-link :to="'/flow/processExample/shenhe?id='+row.id">
                    <el-button type="text"
                               style="color:#303133">&emsp;查看详细</el-button>
                  </router-link>
                </template>
                查看详细
              </el-table-column>
            </el-table>
          </div>
        </el-card>
      </el-col>
      <el-col :span="8"
              height="200">
        <el-card class="box-card">
          <div slot="header"
               class="clearfix">
            <span style="color:#0782e4;font-weight: bold;">我的已办</span>
          </div>
          <div style="margin-bottom:0px;">
            <el-table :data="shenWanData"
                      :show-header="false"
                      style="width: 100%;">
              <el-table-column prop="username"
                               min-width="80">
              </el-table-column>
              <el-table-column prop="processName"
                               min-width="100">
              </el-table-column>
              <el-table-column prop="stratTime"
                               min-width="100">
              </el-table-column>
              <el-table-column>
                <template slot-scope="{row}">
                  <router-link :to="'/flow/processExample/xiangxi?id='+row.id">
                    <el-button type="text"
                               style="color:#303133">&emsp;查看详细</el-button>
                  </router-link>
                </template>
                查看详细
              </el-table-column>
            </el-table>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
import MinuteSv from '@/api/systemGMT/minute'
import NoticSv from '@/api/systemGMT/notic'
import processExampleSv from '@/api/systemGMT/processExample'
export default {
  data () {
    return {
      minuteData: [],
      noticData: [],
      shenqingData: [],
      shenHeData: [],
      shenWanData: [],
      sqlistQuery: {
        page: 1,
        limit: 10,
        stateStr: '',
        sort: true
      },
    }
  },
  mounted () {
    this.getMinuteData();
    this.getNoticData();
    this.getShenQingData();
    this.getShenHeData();
    this.getShenWanData();
  },
  methods: {
    async getMinuteData () {
      var jie = await MinuteSv.getTongjiMinute();
      this.minuteData = jie.data
    }
    , async getNoticData () {
      var jie = await NoticSv.getTongZhiNotic();
      console.log(jie.data);
      this.noticData = jie.data
    }
    , async getShenQingData () {
      var jie = await processExampleSv.getProcessExamples(this.sqlistQuery);
      this.shenqingData = jie.data;
    }
    , async getShenHeData () {
      var jie = await processExampleSv.getShenheProcessExamples(this.sqlistQuery);
      this.shenHeData = jie.data;
      console.log(jie.data);
    }
    , async getShenWanData () {
      var jie = await processExampleSv.getshenheguo(this.listQuery);
      this.shenWanData = jie.data;
    }
  },
}
</script>

<style scoped>
</style>