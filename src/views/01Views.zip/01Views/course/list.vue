<template>
    <div class="app-container">
      <div class="filter-container">
        <el-form :inline="true" class="demo-form-inline">
          <el-form-item label="科目">
            <el-select
              v-model="from.Subject"
              placeholder="科目"
              @change="getSubjectTypes"
            ><el-option label="全部" value="" key=""></el-option>
              <el-option
                v-for="(item, index) in Subjects"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="科目级别">
            <el-select
              placeholder="科目级别"
              v-model="from.SubjectType"
              @change="getCourses"
            >
              <el-option
                v-for="(item, index) in SubjectTypes"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item>
          <!-- <el-form-item label="课程">
            <el-select placeholder="课程" v-model="from.Course">
              
              <el-option
                v-for="(item, index) in Courses"
                :key="index"
                :label="item.label"
                :value="item.value"
              >
              </el-option>
            </el-select>
          </el-form-item> -->
          <el-form-item label="资讯">
            <el-input 
              v-model="from.searchTitle"
              placeholder=""
            ></el-input>
           
          </el-form-item>
          <el-button class="filter-item" type="primary" icon="el-icon-search" @click="handleSubmit">
            查询
          </el-button>
          <el-button
            class="filter-item"
            style="margin-left: 10px"
            type="primary"
            icon="el-icon-edit"
            @click="handleCreate"
          >
            新增
          </el-button>
        </el-form>
      </div>
  
      <!-- 表格 -->
      <el-table
        :data="list"
        style="width: 100%"
        row-key="id"
        highlight-current-row
        border
        lazy
        :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
        @current-change="selectChange"
      >
        <el-table-column label="操作" width="160">
          <template slot-scope="scope">
            <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-popconfirm
              class="btnspace"
              title="确定删除吗，小程序已配置的该资讯也会一并清除！"
              @onConfirm="handleDelete(scope.$index, scope.row)"
            >
              <el-button slot="reference" type="danger" size="mini"
                >删除</el-button
              >
            </el-popconfirm>
          </template>
        </el-table-column>
        <el-table-column prop="informationId" label="InformationId" v-if="false" />
        <el-table-column prop="bannnerUrl" label="Url" v-if="false" />
        <el-table-column prop="subjectName" label="科目" />
        <el-table-column prop="subjectType" label="科目级别" />
        <!-- <el-table-column prop="courseId" label="课程名称" /> -->
        <el-table-column prop="informationTitle" label="资讯名称" />
        <el-table-column prop="lastUpdateDate" label="修改时间" />
        <el-table-column prop="lastUpdateUserName" label="修改人" />
      </el-table>
      <!-- 添加窗口 -->
      <el-drawer :visible.sync="openedWin"  size="35%" :destroy-on-close="true" >
        <template slot="title"><h3>{{ optype == "Create" ? "添加" : "修改" }}</h3></template>
        <component :is="optype" :Selectdata="currentFun" @closeDrawer="closeDrawer" />
      </el-drawer>
      <div class="block">
        <el-pagination
          :current-page="from.pageIndex"
          :page-sizes="[5, 8, 10, 15, 20]"
          :page-size="from.pageSize"
          background
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @current-change="pageChange"
          @size-change="sizeChange"
        />
      </div>
    </div>
  </template>
  <script>
//   import request from "@/utils/request";
//   import Create from "./create";
//   import edit from './edit'
  export default {
    components: {
      Create,edit
    },
    data() {
      
      return {
        total: 0,
        selectRow: "",
        dialogVisible: false,
  
        openedWin: false, // 打开对话框
        list: [],
        currentFun: {}, // 当前选中的行
        optype: "Create", // 操作类型 create还是edit
  
        from: {
          pageIndex: 1,
          pageSize: 5,
          Subject: "",
          SubjectType: "",
          Course: "",
          searchTitle:"",
        },
  
        Subjects: [],
        SubjectTypes: "",
        Courses:"",
      
      };
    },
    mounted() {
    //   this.getSubjects();
    //   this.getList(this.from);
    },
    
    methods: {
      //加载列表
    //   getList(data) {
    //     request({
    //       url: "Information/GetInformationList",
    //       method: "post",
    //       data
    //     }).then((res) => {
    //       console.log(res);
    //       if(res.code==200){
    //         this.list=res.data;
    //         this.total=res.total;
    //       }else{
    //         alert("错误")
    //       }
    //     });
    //   },
    //   getSubjects() {
    //     request({
    //       url: "Subject/GetSubject",
    //       method: "get",
    //     }).then((res) => {
    //       this.from.SubjectType = "";
    //       this.SubjectTypes = "";
    //       this.from.Course = "";
    //       this.Courses = "";
    //       this.Subjects = res.data;
    //     });
    //   },
    //   getSubjectTypes() {
    //     if(this.from.Subject!=""&&this.from.Subject!=undefined){
    //       request({
    //         url: "SubjectType/GetSubjectTypeById?SubjectId=" + this.from.Subject,
    //         method: "get",
    //       }).then((res) => {
    //         this.from.SubjectType = "";
    //         this.SubjectTypes = "";
    //         this.from.Course = "";
    //         this.Courses = "";
    //         this.SubjectTypes = res.data;
    //       });
    //     }else{
    //         this.from.SubjectType = "";
    //         this.SubjectTypes = "";
    //         this.from.Course = "";
    //         this.Courses = "";
    //     }
    //   },
    //   getCourses() {
    //     request({
    //       url: "Course/GetCourseBySubjectType?id=" + this.from.SubjectType,
    //       method: "get",
    //     }).then((res) => {
    //       this.Courses = res;
    //     });
    //   },
    //   handleSubmit() {
    //     request({
    //       url: "Information/GetInformationList",
    //       method: "post",
    //       data: this.from,
    //     }).then((res) => {
    //       if(res.code==200){
    //         this.list=res.data;
    //         this.total=res.total;
    //       }else{
    //         alert("错误")
    //       }
    //     });
    //   },
  
     
    //   handleCreate() {
    //     this.currentFun = {};
    //     this.optype = "Create";
    //     this.openedWin = true;
    //   },
    //   handleEdit(index, row) {
        
    //     this.currentFun = row
    //     console.log(this.currentFun);
    //     this.optype = 'edit'
    //     this.openedWin = true
    //   },
    //   // 删除
    //   handleDelete(index, row) {
    //     request({
    //       url: "Information/DeleteInformation?InformationId="+row.informationId,
    //       method: "post",
    //     }).then((res) => {
    //           if (res.code == 200) {
    //             this.$message({
    //               message: '成功！',
    //               type: 'success'
    //             });
    //           }else if(res.code==201){
    //             this.$message({
    //               message: res.msg,
    //               type: 'warning'
    //             });
    //           }
    //            else {
    //             this.$message.error('失败');
    //             return false;
    //           }
    //           this.getList(this.from);
    //     });
    //   },
    //   // 翻页
    //   pageChange(index) {
    //     this.from.pageIndex = index;
    //     this.getList(this.from);
    //   },
    //   // 调页数
    //   sizeChange(size) {
    //     this.from.pageSize = size;
    //     this.getList(this.from);
    //   },
    //   // 当前选择行
    //   selectChange(row, old) {
    //     this.currentFun = row;
    //   },
    //   // 关闭抽屉
    //   closeDrawer(reflash) {
    //     this.openedWin = false
    //     if (reflash) {
    //       this.getList(this.from);
    //     }
    //   }
      
    },
  };
  </script>
  <style scoped>
  .btnspace {
    margin-left: 10px;
  }
  </style>
  