<template>
  <el-row :gutter="20" style="padding-left: 30px; padding-top: 50px;">
    <el-col :span="16">
      <div class="grid-content bg-purple">
        <el-form  :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
          <el-form-item label="活动名称" prop="name">
            <el-input v-model="ruleForm.name"></el-input>
          </el-form-item>
          <el-form-item label="活动地址" prop="region">
            <el-input v-model="ruleForm.region"></el-input>
          </el-form-item>
          <el-form-item label="活动时间" prop="date1">
            <div class="block">
              <span class="demonstration"></span>
              <el-date-picker v-model="ruleForm.date1" type="datetimerange" start-placeholder="开始日期" end-placeholder="结束日期"
                :default-time="['12:00:00']">
              </el-date-picker>
            </div>
          </el-form-item>
          <el-form-item label="报名费用" prop="price" style="width: 250px;" > 
            <el-input placeholder="费用"  v-model.number="ruleForm.price"></el-input>
          </el-form-item>
          <el-form-item label="限制人数" prop="maxStudents" style="width: 250px;" > 
            <el-input placeholder="最大人数"  v-model.number="ruleForm.maxStudents"></el-input>
          </el-form-item>
          <el-form-item label="即时发布" prop="isno">
            <el-switch v-model="ruleForm.isno"></el-switch>
          </el-form-item>
          <!-- <el-form-item label="活动性质" prop="type">
            <el-checkbox-group v-model="ruleForm.type">
              <el-checkbox label="美食/餐厅线上活动" name="type"></el-checkbox>
              <el-checkbox label="地推活动" name="type"></el-checkbox>
              <el-checkbox label="线下主题活动" name="type"></el-checkbox>
              <el-checkbox label="单纯品牌曝光" name="type"></el-checkbox>
            </el-checkbox-group>
          </el-form-item> -->
          <!-- <el-form-item label="特殊资源" prop="resource">
            <el-radio-group v-model="ruleForm.resource">
              <el-radio label="线上品牌商赞助"></el-radio>
              <el-radio label="线下场地免费"></el-radio>
            </el-radio-group>
          </el-form-item> -->
          <el-form-item label="活动介绍" prop="desc">
            <el-input type="textarea" v-model="ruleForm.desc"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">立即创建</el-button>
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-col>

  </el-row>

</template>

<script>
export default {
  data() {
    var checknumber = (rule, value, callback) => {
        if (!value) {
          return callback(new Error('不能为空'));
        }
        setTimeout(() => {
          if (!Number.isInteger(value)) {
            callback(new Error('请输入数字值'));
          }
        }, 1000);
      };
    return {
      ruleForm: {
        name: '',
        region: '',
        date1: '',
        isno: false,
        type: [],
        resource: '',
        desc: ''
      },
      rules: {
        name: [
          { required: true, message: '请输入活动名称', trigger: 'blur' },
        ],
        region: [
          { required: true, message: '请设置活动地址', trigger: 'change' }
        ],
        date1: [
          {  required: true, message: '请选择日期', trigger: 'change' }
        ],
        
        type: [
          { type: 'array', required: true, message: '请至少选择一个活动性质', trigger: 'change' }
        ],
        resource: [
          { required: true, message: '请选择活动资源', trigger: 'blur' }
        ],
        desc: [
          { required: true, message: '请填写活动介绍', trigger: 'blur' }
        ],
        price: [
            { validator: checknumber,required: true, message: '请填写金额', }
        ],
        maxStudents: [
            { validator: checknumber, required: true, message: '请填写最大人数'}
        ]
      }
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!');
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    }
  }
}
</script>

<style></style>